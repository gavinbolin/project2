#include "Token.h"

/*Token::Token(TokenType type, std::string description, int line) {
     = type;
    desc = description;
    lineNumber = line;
    // TODO: initialize all member variables
}*/
